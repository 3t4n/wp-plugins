<?php
/*
Plugin Name: Get My Custom
Author URI: coming soon.
Description: Gives you the ability to get a custom field for the page or post currently being viewed OUTSIDE the loop. 
Version: 1.0
Author: Paul Whitehead
*/

/*
This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

notes:
this is my first wordpress plugin and is simply a function i made and have found useful in the past, i share it with the community in the hope that it could be useful. I was greatly helped by reading 'all in one SEO pack' code.

tested on wordpress 2.7 and 2.8, if you use it on other versions let me know :)

installation:
simply add this file to your wordpress plugins folder and activate it from with the wordpress plugin page. 

usage:
add the function to a template page calling whichever custom field you would like to get. 

e.g. 
get_my_custom('my_mood', TRUE);

will echo the custom field my_mood from whatever page

$my_mood = get_my_custom('my_mood');
echo $my_mood;

will assign the contents of the my_mood custom field to the the variable $my_mood and allow you to manipulate it as you like, in this case my echoing its contents. 

*/

function get_my_custom($cf_name = '', $echo = FALSE) {
	
global $wp_query;

	$content_array = $wp_query->get_queried_object();
	$current_id = $content_array->ID;
	$output = get_post_meta($current_id, $cf_name, true);
	
	if ($echo === TRUE) :
		echo $output;
	else :
		return $output;
	endif;
}
?>