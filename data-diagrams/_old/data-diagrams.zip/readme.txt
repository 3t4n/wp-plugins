

	=== Data Diagrams ===
	Contributors: Data-Diagrams.com
	Tags: datadiagrams
	Requires at least: 6.0
	Tested up to: 6.6
	Stable tag: 1.1
	License: GPLv2 or later
	License URI: http://www.gnu.org/licenses/gpl-2.0.html
 
	WordPress plugin for importing and integrating data diagrams and visualising charts from https://data-diagrams.com  
 
	== Description ==

	This plugin is an extension to WordPress for importing and integrating stunning visualising SVG charts from data-diagrams.com. The portal gives access to 33 different kind of data charts. Using the Free Edition, the SVG diagrams are imported into Word Press Media Library to be embedded onto the pages in WP. Using the Free Pro Edition, the SVG diagrams are downloaded and embedded into the pages as responsive SVG using Smart Codes:
	
	- Bar Charts (6 types with 2 variants each)
	- Area Chars (6 types with 2 variants each)
	- Function/line Chars (2 types with 2 variants each)
	- Point Charts (2 types with 2 variants each)
	- Mixed Charts (2 types with 2 variants each)

	- Donut Charts (3 types)
	- Pie Charts (2 types)

	- Spider Web Charts (2 types)
	- Radar Web Charts (3 types)
	- Spider Radar Chart

	- Gauge Charts

	- Bubble Charts (3 types)

	data-diagrams.com is a web portal for easily creating data visualising SVG charts without any programming skills required. Everything is defined through an easy graphical user interface. Finally, the designed diagram can be downloaded into WordPress. When data needs updates or the diagram in other ways needs changes, it is easily done through the graphical editor. 

	Further more, there is a model for dynamic data integration on your own web site. The diagram is produced by XML Stylesheet generating SVG from XML data. Guidance is provided on how to produce the XML data from your inhouse systems. When the diagrams needs other updates than data, a new XML Stylesheet (XSL) is produced through the graphical user interface on the portal, and the XSL is replaced onto your own system making it easy to make changes on a day to day basis.
 
 
	https://data-diagrams.com/privacy.html



	== Installation ==
 
	1. Go to the 'Plugins' admin page, upload the data-diagrams.zip and activate the plugin.
	2. A new menu item 'Data Diagrams' is created
 
	== Frequently Asked Questions ==
 
	= How do I use this plugin? =
 
	Follow the guide on the admin page.
 
	= How to uninstall the plugin? =
 
	Simply deactivate and delete the plugin. 
  
	== Changelog ==
	= 1.0 =
	* Plugin released.


	== Terms of Use ==

This Terms of Use Agreement (the "Agreement") is between Cartouche Limited, Denmark, and the end user ("You").

1. Grant of the License
Subject to the terms and conditions of this License, and subject to payment of applicable fees (License Fee), Data-Diagrams grants You a limited, personal, non-exclusive, non-transferable, non-sub-licensable and revocable license to install during the Term and solely for your own private use, three (3) Copies of the Data-Diagrams Software and related written materials in either printed text or machine readable version (the "Documentation"). Any use of more copies of the Data-Diagrams Software than are licensed is prohibited. The license for the Data-Diagrams Software may not be shared by alternating use of the Data-Diagrams Software between different computers. Following expiry of the Term, You may keep one copy of the Data-Diagrams Software under the terms of the last License that you accepted. These limitations apply even if you receive the Data-Diagrams Software on multiple media (e.g. electronic download and CD). For the purposes of this Agreement, "Copy" shall include the original installation of the Data-Diagrams Software. You shall not allow and shall prevent others from making or obtaining copies of the Data-Diagrams Software.

2. License Restrictions
Unless specifically permitted in terms of this Agreement, You may not (i) copy, reproduce, change, modify, create a derivative work thereof, reverse compile or reverse engineer, disassemble, decompile or otherwise attempt to extract the source code or internal data of the Data-Diagrams Software or any part thereof; (ii) remove or in any way obscure any ownership or trademark notices on the Data-Diagrams Software; (iii) sublicense, sell, rent, lease, transfer, assign, display, host, outsource, disclose, distribute or otherwise commercially exploit the Data-Diagrams Software; (iv) circumvent any serial number or any other mechanism used or deployed by Data-Diagrams to protect the Data-Diagrams Software against unlicensed use, copying or distribution; (v) post or otherwise make available, the Data-Diagrams Software or any portion thereof, including the serial number, on the Internet or other publicly available forum; (vi) export or re-export the Data-Diagrams Software or any underlying information or technology in violation of the export laws of the United States, the European Community or any other applicable laws or regulations; or (vii) make any use of such Data-Diagrams Software in any way that violates any applicable law.

3. Licensed Copies and Networks
Any simultaneous storage, maintenance, or use of the Data-Diagrams Software is prohibited. You agree either to implement access security mechanisms to prevent simultaneous use or to pay an additional fee according to the number of users with access to a network enabling use of the Data-Diagrams Software by multiple computers simultaneously.

4. Upgrades and Content Updates
Data-Diagrams may provide You with Upgrades and/or Content Updates from time to time at no charge during the Term of this Agreement. For the purposes hereof, "Upgrade" means a new version of the Data-Diagrams Software containing technical modifications, updated information, altered functionality, or any other changes that are intended by Data-Diagrams to improve or to add to, delete or otherwise modify any aspect of the Data-Diagrams Software; and "Content Update" means an update of the content used by the Data-Diagrams Software that might need to be updated from time to time. Upgrades and/or Content Updates may be provided by Data-Diagrams via on-line services. This License does not otherwise permit You to obtain and use Upgrades and/or Content Updates. Note: The Data-Diagrams Software may require Content Updates in order to work effectively.

5. Evaluation Copy
You may be granted an evaluation copy of the Data-Diagrams Software free of charge (the "Evaluation Copy"). Certain features and/or functionality of the Data-Diagrams Software may be locked or unavailable in the Evaluation Copy. In order to benefit from all features and functionality of the Data-Diagrams Software, You must pay the License Fee and input a valid serial number. Upon such actions being taken, the Evaluation Copy shall cease from being considered an Evaluation Copy and all the terms of this Agreement shall commence to apply in their entirety. Clauses 3, 9, 10, 11, 12, 13, 14, 15, 19 and 20 shall apply equally to an Evaluation Copy.

6. Activation and other Technological Measures
When You purchase a license You will be provided with a serial number. You must activate the Data-Diagrams Software by entering the serial number as prompted by such Software. There may be other technological measures, including enforcement technology, in the Data-Diagrams Software that are designed to prevent unlicensed or illegal use. You agree that Data-Diagrams may use these measures in its reasonable discretion. 8. Intellectual Property Protection The Data-Diagrams Software is protected by copyright, as well as other intellectual property laws both nationally and under international treaty provisions. Notwithstanding anything else, the Data-Diagrams Software is licensed and not sold. This License Agreement does not give You any intellectual property rights in the Data-Diagrams Software or any Third Party Software, and does not grant You any license, right or interest in any trade mark, trade name or service mark of Data-Diagrams or any other third party. Data-Diagrams owns and retains all right, title and interest in and to the Data-Diagrams Software, all Copies or portions of the Data-Diagrams Software, and any derivative works thereof.

7. Limited Warranty
The Data-Diagrams Software is provided to You under this License on an ìas isî basis, without warranty or representation of any kind. The Data-Diagrams Software is provided as general purpose software and not for your particular use. You accept that Data-Diagrams and its suppliers do not represent or warrant that the Data-Diagrams Software will meet your requirements or be error or defect free or that any defects in the operation or functionality of the Data-Diagrams Software will be corrected. Data-Diagrams further expressly disclaims all warranties and conditions of any kind, whether express or implied, including, but not limited to, the implied warranties of merchantability, fitness for a particular purpose and non-infringement of intellectual property rights. Any implied warranties that cannot be excluded are limited to thirty (30) days or to the shortest period permitted by applicable law, whichever is the greater. Your use of the Data-Diagrams Software is at your sole risk and You are responsible for any decisions made and actions taken based on the Data-Diagrams Software, irrespective of any recommendations preferred by such Software. Data-Diagrams makes no representation regarding Third Party Software which may be accessed through or included with the Data-Diagrams Software.

8. Limitation of Liability.
TO THE MAXIMUM EXTENT PERMITTED BY LAW, UNDER NO CIRCUMSTANCE AND UNDER NO LEGAL THEORY/INSTITUTE, WHETHER IN TORT, CONTRACT OR OTHERWISE, WILL Data-Diagrams OR ITS SUPPLIERS, BE LIABLE TO YOU OR ANY THIRD PARTY BENEFICIARY FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL, EXEMPLARY, PUNITIVE OR CONSEQUENTIAL DAMAGES (INCLUDING BUT NOT LIMITED TO ANY DAMAGE FOR LOSS OF BUSINESS, LOSS OF PROFITS, LOSS OF DATA, LOSS OF PRIVACY, LOSS OF CONFIDENTIAL OR OTHER INFORMATION, COMPUTER FAILURE OR MALFUNCTION AND FOR ANY OTHER PECUNIARY OR OTHER LOSS WHATSOEVER) ARISING OUT OF, OR IN ANY WAY RELATED TO, THE USE OR THE INABILITY TO USE THE Data-Diagrams SOFTWARE, THE PROVISION OF OR FAILURE TO PROVIDE SUPPORT SERVICES, OR OTHERWISE IN CONNECTION WITH ANY ASPECT OF THIS SOFTWARE, EVEN IN THE EVENT OF THE FAULT, TORT (INCLUDING NEGLIGENCE), STRICT LIABILITY, BREACH OF CONTRACT OR BREACH OF WARRANTY, AND EVEN IF Data-Diagrams OR ITS SUPPLIERS HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES. IN NO EVENT WILL THE TOTAL LIABILITY OF Data-Diagrams OR ITS SUPPLIERS WHETHER IN TORT, CONTRACT OR OTHERWISE, EXCEED THE AMOUNT ACTUALLY PAID BY YOU FOR THE Data-Diagrams SOFTWARE (ìLICENSE FEEî). YOU ACKNOWLEDGE THAT THE LICENSE FEE REFLECTS THIS ALLOCATION OF RISK AND THAT THE LIMITATION SET FORTH IN THIS SECTION IS AN ESSENTIAL ELEMENT OF THE AGREEMENT BETWEEN THE PARTIES. Some jurisdictions do not allow the exclusion or limitation of liability, so the above limitations might not apply to You.

9. Indemnity
You will indemnify and hold Data-Diagrams harmless from any and all claims, losses, liabilities, damages, fines, penalties, costs and expenses (including attorneys fees) arising from or relating to your use of the Data-Diagrams Software. Your obligations under this section shall survive the expiration or termination of this Agreement.

10. Privacy
You agree that Data-Diagrams may collect and use information transmitted through the Data-Diagrams Software to improve its products and services. Any personal information pertaining to You, which may be held by Data-Diagrams (e.g. further to support services provided to You) shall be processed in accordance with the Data-Diagrams Privacy Policy, as it exists at any relevant time. You may access our Privacy Policy at any time at http://www.Data-Diagrams.com/privacy.

11. Third Party Software
Other third party software may be distributed together with the Data-Diagrams Software (the ìThird Party Softwareî). Any and all such Third Party Software may require notices and/or be subject to different license terms. By accepting this License Agreement, You are also accepting the license terms, if any, under which the Third Party Software is made available. You will not enter into a contractual relationship with Data-Diagrams regarding such Third Party Software and Data-Diagrams accepts no responsibility for Your use of same.

12. Term and Termination
The Term of this License is for a period of one year from the date of purchase except with regards to an Evaluation Copy for which the default term shall be for so long as Data-Diagrams makes such Evaluation Copy available to You. At the end of the Term, You agree to de-install and destroy or permanently erase all but one copy of the Data-Diagrams Software within fifteen (15) days of termination or expiration. Following expiry of the Term, some features and functionality of the Data-Diagrams Software may cease to function or the Data-Diagrams Software may cease to function altogether. Notwithstanding the above, the License shall automatically terminate if You fail to comply with any of its terms, both during and following the Term of the License, without prejudice to the rights of Data-Diagrams to compensation for damages in terms of the applicable law. Immediately upon such termination, any license granted hereunder shall terminate and You shall immediately return to Data-Diagrams or destroy all Copies of the Data-Diagrams Software in Your possession. The terms of this Agreement which are intended to survive expiration or termination shall remain in effect.

13. Support
Data-Diagrams may provide You with support services related to the Data-Diagrams Software. Any obligation Data-Diagrams may have to support the previous version of the Data-Diagrams Software ends upon the expiration of the Term or the termination of the License, whichever is the earlier. Support may not be available in the language in which the Data-Diagrams Software was acquired.

14. Modifications
If Upgrades are granted, such Upgrades shall be accompanied by this or a new License. Such grant shall not extend the Term of the License granted hereunder. If the Upgrade is accompanied by a new License, and You do not accept the terms of such new License, You must notify Data-Diagrams within thirty (30) days of such grant. If you do so notify Data-Diagrams, your agreement with Data-Diagrams shall continue to be governed by this or the last License that you accepted, until the end of the Term. Following expiry of the Term, if you renew your license of the Data-Diagrams Software or you continue to pay your License Fee, you will be deemed to have accepted the new license.

15. General Provisions
Any rights not expressly granted under this License Agreement are being reserved. This License is the entire agreement between You and Data-Diagrams with respect to this subject matter and supersedes any and all prior or contemporaneous oral or written agreements, representations, negotiations, any additional terms or other similar communication between the parties. If any part of this License Agreement is found to be void, unenforceable or invalid, that part will be deemed stricken and will not affect the validity of the other License provisions. Failure by either party to enforce any provision of this License will not be deemed a waiver of future enforcement of that or any other provision.

16. Choice of Law
This License Agreement will be governed by and construed under the Laws of Denmark, excluding any conflict of rules of law. All disputes arising out of or in relation to this Agreement shall be submitted to the exclusive jurisdiction of the Courts of Denmark. Data-Diagrams retains the right, at its option, to pursue any litigation arising from your use of the Data-Diagrams Software in your national Courts.

17. Value Added Tax
Users outside Denmark agree to pay the local value added tax directly to the authorities of the local jurisdiction without any involvement or compensation from Cartouche Limited, Denmark.

18. Newsletters
By agreeing this end-user agreement you at the same time grant permission for Cartouche Limited incl. Data-Diagrams to send you emails for any purpose including newsletters. However, you are able to dismiss the desire for newsletters in the User Dialog.
