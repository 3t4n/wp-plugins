=== Contact-Form ===
Contributors: Dhrup IT Solutions
Donate link: https://dhrup.com/donate/
Tags: contact, contact form, email
Requires at least: 4.0
Tested up to: 4.9
Requires PHP: 5.2.4
Stable tag: 4.3

Just another contact form plugin. Simple but flexible.

== Description ==

Contact-Form validate email address then send email.

== Changelog == 

= Contact-Form Needs Your Support =

It is hard to continue development and support for this free plugin without contributions from users like you. If you enjoy using Contact-Form and find it useful, please consider [__making a donation__](https://dhrup.com/donate/). Your donation will help encourage and support the plugin's continued development and better user support.


== Installation ==

1. Upload the entire `Contact-Form` folder to the `/wp-content/plugins/` directory.
1. Activate the plugin through the 'Plugins' menu in WordPress.

Add below shortcode to include contact form in wordpress pages: 
[contact-form-plugin]

== Frequently Asked Questions ==

[Support](https://dhrup.com)


== Screenshots ==
1. Screenshot_1.png


