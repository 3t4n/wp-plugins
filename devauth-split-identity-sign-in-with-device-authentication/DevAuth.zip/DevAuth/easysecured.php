<?php
/**
 *  Encryption / Decryption using 256 bit encryption.
 *
 * This class is meant to facilitate encryption / decryption of keys using device identity.
 */

function myplugin_inner_custom_box() {
	echo "DevAuth protects your WordPress account by locking your password to a registered device; such as your smartphone and by remote partial login using the password from the registered smartphone.<br><br>You access your account thereafter by only entering your account username or email address from any computer. <br><br>To learn more about DevAuth Split Identity, visit <b><a href='http://www.devauth.com/how.html' target='blank'>How DevAuth Works</a></b>";
}

function mencrypt($string,$key) {
  $encrypted = base64_encode(mcrypt_encrypt(MCRYPT_RIJNDAEL_256, md5($key), $string, MCRYPT_MODE_CBC, md5(md5($key))));
  return $encrypted;
}

function mdecrypt($string,$key) {
  $decrypted = rtrim(mcrypt_decrypt(MCRYPT_RIJNDAEL_256, md5($key), base64_decode($string), MCRYPT_MODE_CBC, md5(md5($key))), "\0");
  return $decrypted;
}

global $jal_db_version;
$jal_db_version = "1.0";

function jal_install() {

   global $wpdb;
   global $jal_db_version;
   $installed_ver = get_option( "jal_db_version" );
	
   $table_name = $wpdb->prefix . "devauth";
	session_start();
	$_SESSION["table_name"] = $table_name;
   
		$sql = "CREATE TABLE $table_name (
		ukey VARCHAR(256) DEFAULT '' NOT NULL,
		pkey VARCHAR(256) DEFAULT '' NOT NULL,
		tkey VARCHAR(256) DEFAULT '' NOT NULL,
		tp datetime DEFAULT '0000-00-00 00:00:00' NOT NULL
		);";

		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
		dbDelta( $sql );
 
		add_option( "jal_db_version", $jal_db_version );
}

   
?>