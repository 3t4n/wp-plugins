<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>
	<head>
		<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
		<title><?php bloginfo('name'); ?> &rsaquo; <?php echo __( 'Log in' ); ?></title>
<style type="text/css">body,td,th {	font-family: Georgia,"Times New Roman",Times,serif;;	font-size: 12px;	color: #333;}body {	margin-left: 0px;	margin-top: 30px;	margin-right: 0px;	margin-bottom: 0px;}.maindiv{ width:790px; margin:0 auto; padding:20px; background:#CCC;}.innerbg{ padding:6px; background:#FFF;}.result{ border:solid 1px #CCC; margin:10px 2px; padding:4px 2px;}.title a{ font-weight:bold; color:#c24f00; text-decoration:none; font-size:14px;}.discptn a{ text-decoration:none; color:#999;}.link a{ color:#008000; text-decoration:none;}img{ cursor:pointer;}</style>
		
	<?php

	// wp_admin_css( 'wp-admin', true );
	// wp_admin_css( 'colors-fresh', true );

	// Don't index any of these forms
	add_action( 'login_head', 'wp_no_robots' );

	if ( wp_is_mobile() ) { ?>
		<meta name="viewport" content="width=320; initial-scale=0.9; maximum-scale=1.0; user-scalable=0;" /><?php
	}

	// Shake it!
	$shake_error_codes = array( 'empty_email', 'invalid_email' );
	$shake_error_codes = apply_filters( 'shake_error_codes', $shake_error_codes );

	if ( $shake_error_codes && !wp_is_mobile() && $this->front_notices->get_error_code() && in_array( $this->front_notices->get_error_code(), $shake_error_codes ) ) {
?>
		<script type="text/javascript">
		addLoadEvent = function(func){if(typeof jQuery!="undefined")jQuery(document).ready(func);else if(typeof wpOnload!='function'){wpOnload=func;}else{var oldonload=wpOnload;wpOnload=function(){oldonload();func();}}};
		function s(id,pos){g(id).left=pos+'px';}
		function g(id){return document.getElementById(id).style;}
		function shake(id,a,d){c=a.shift();s(id,c);if(a.length>0){setTimeout(function(){shake(id,a,d);},d);}else{try{g(id).position='static';wp_attempt_focus();}catch(e){}}}
		addLoadEvent(function(){ var p=new Array(15,30,15,0,-15,-30,-15,0);p=p.concat(p.concat(p));var i=document.forms[0].id;g(i).position='relative';shake(i,p,20);});
		</script>
<?php
	}

	do_action( 'login_enqueue_scripts' );
	do_action( 'login_head' );

	if ( is_multisite() ) {
		$login_header_url   = network_home_url();
		$login_header_title = $current_site->site_name;
	} else {
		$login_header_url   = __( 'http://WordPress.org/' );
		$login_header_title = __( 'Powered by WordPress' );
	}

	$login_header_url   = apply_filters( 'login_headerurl',   $login_header_url   );
	$login_header_title = apply_filters( 'login_headertitle', $login_header_title );

	?>
	</head>
	<body class="login<?php if ( wp_is_mobile() ) echo ' mobile'; ?>">
<div style="text-align:center;">

  <div style="width:730px; margin:0 auto;"></div>
<div class="maindiv"><div class="innerbg">
<h1>DevAuth</h1>
<h3>WordPress Device Authentication</h3>
<hr>
<table width="100%" border="0" cellpadding="2" cellspacing="2">
  <tr>
    <td align="left" valign="middle" bgcolor="" border="1"><div style="margin:0px 10px; font-weight:bold;  font-size:12px;">
	<h2>Welcome to DevAuth</h2>
		<?php

	unset( $login_header_url, $login_header_title );

	$message = '';
	$message = apply_filters('login_message', $message);
	if ( !empty( $message ) )
		echo $message . "\n";

	if ( $this->front_notices->get_error_code() ) {
		$errors = '';
		$messages = '';
		foreach ( $this->front_notices->get_error_codes() as $code ) {
			$severity = $this->front_notices->get_error_data($code);
			foreach ( $this->front_notices->get_error_messages($code) as $error ) {
				if ( 'message' == $severity )
					$messages .= '	' . $error . "<br />\n";
				else
					$errors .= '	' . $error . "<br />\n";
			}
		}
		if ( !empty($messages) )
			echo '<p class="message">' . apply_filters('login_messages', $messages) . "</p>\n";
	}

	?>
	
	
	</div></td>
	
    </tr>
	
  <tr>
    <td align="center" valign="middle">
	<hr>
	
<div style="margin:0 auto; padding:8px 4px; text-align:center; width:560px;">

	
	<?php


	if ( !$request_login ) : ?>
			<form name="loginform" id="loginform" action="<?php echo esc_url( home_url( $this->login_page, 'login_post' ) ); ?>" method="post">
<table width="100%" border="0" align="center" cellpadding="4" cellspacing="4">
  <t-0'r>
    <td align="right" valign="middle">Email Address</td>
    <td align="left" valign="middle">:</td>
    <td align="left" valign="middle"><label>
      <input type="email" name="user_email" id="user_email" class="input" value="<?php echo esc_attr(stripslashes($user_email)); ?>" size="25" />
    </label></td>
  </tr>
  <tr>
    <td align="right" valign="middle">Password</td>
    <td align="left" valign="middle">:</td>
    <td align="left" valign="middle"><label>
    <input type="password" name="user_pass" id="user_pass" class="input" value="<?php echo esc_attr(stripslashes($user_pass)); ?>" size="25" /></label>
    </label></td>
  </tr>
  
  <tr>
    <td align="left" valign="middle">&nbsp;</td>
    <td align="left" valign="middle">&nbsp;</td>
    <td align="left" valign="middle"><label>
					<input type="submit" name="wp-submit" id="wp-submit" class="button-primary" value="<?php esc_attr_e('Log In'); ?>" />
					<input type="hidden" name="redirect_to" value="<?php echo esc_attr($redirect_to); ?>" />
					<input type="hidden" name="testcookie" value="1" />
					<?php wp_nonce_field( 'DevAuth_login_request', 'nonce', false ) ?>
	  
    </label></td>
  </tr>
  
</table>


			</form>
<div id="status">
<?php
		if ( !empty($errors) )
			echo '<div id="login_error">' . apply_filters('login_errors', $errors) . "</div>\n";
?>
</div>				
			
<?php
 endif;
?>
</div>
    </td>
    </tr>
</table>
</div>

</div>
			<p id="backtoblog">
			<a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php esc_attr_e( 'Are you lost?' ); ?>"><?php printf( __( '&larr; Back to %s' ), get_bloginfo( 'title', 'display' ) ); ?></a>
			</p>
		<?php do_action('login_footer'); ?>
		<div class="clear"></div>
	</body>
</html>